/* $Id: dummy.c,v 1.2 2005/07/07 15:21:52 dron Exp $ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

static void
libport_dummy_function()
{
        return;
}

