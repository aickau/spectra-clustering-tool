#include <ctype.h>
#if ((' ' & 0x0FF) == 0x020)
# define ISLOWER(c) ('a' <= (c) && (c) <= 'z')
# define TOUPPER(c) (ISLOWER(c) ? 'A' + ((c) - 'a') : (c))
#else
# define ISLOWER(c) \
     (('a' <= (c) && (c) <= 'i') \
	 || ('j' <= (c) && (c) <= 'r') \
	 || ('s' <= (c) && (c) <= 'z'))
# define TOUPPER(c) (ISLOWER(c) ? ((c) | 0x40) : (c))
#endif

#define XOR(e, f) (((e) && !(f)) || (!(e) && (f)))
int
  main ()
{
   int i;
   for (i = 0; i < 256; i++)
     if (XOR (islower (i), ISLOWER (i)) || toupper (i) != TOUPPER (i))
       exit(1);
   exit (0);
}
