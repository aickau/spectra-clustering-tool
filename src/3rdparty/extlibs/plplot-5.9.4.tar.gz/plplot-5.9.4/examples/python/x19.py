#!/usr/bin/env python
#
#	x19c.c
#
#	Illustrates backdrop plotting of world, US maps.
#	Contributed by Wesley Ebisuzaki.

# This demo could not be converted to Python because it uses a part of
# the plplot API that has not yet been implemented in Python.
