/* $Id: plc++demos.h 9617 2009-02-25 22:03:03Z smekal $

	All the common includes and constants needed by the C++ demo programs.
*/

#ifndef __PLCXXDEMOS_H__
#define __PLCXXDEMOS_H__

/* plplot actually includes the C versions of these 2, but
 * add here for completeness */
#include <cstdio>
#include <cstdlib>

#include <iostream>
#include <cstring>
#include <cmath>

/* common includes */
#include "plstream.h"

/* common defines */
#ifndef M_PI
#define M_PI 3.1415926535897932384
#endif

/* various utility macros */
#ifndef ROUND
#define ROUND(a) (PLINT)((a)<0. ? ((a)-0.5) : ((a)+0.5))
#endif

#endif	/* __PLCXXDEMOS_H__ */
